<div class="ts-toast">
    <!-- Toast message will be dynamically added here -->
</div>