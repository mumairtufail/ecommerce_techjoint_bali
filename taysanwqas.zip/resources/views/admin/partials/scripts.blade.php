<!-- jQuery -->
    <script src="{{ asset('dashboard/vendors/jquery/dist/jquery.min.js') }}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('dashboard/vendors/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('dashboard/vendors/bootstrap/dist/js/bootstrap.min.js') }}"></script>

    <!-- Slimscroll JavaScript -->
    <script src="{{ asset('dashboard/dist/js/jquery.slimscroll.js') }}"></script>

    <!-- Fancy Dropdown JS -->
    <script src="{{ asset('dashboard/dist/js/dropdown-bootstrap-extended.js') }}"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="{{ asset('dashboard/dist/js/feather.min.js') }}"></script>

    <!-- Toggles JavaScript -->
    <script src="{{ asset('dashboard/vendors/jquery-toggles/toggles.min.js') }}"></script>
    <script src="{{ asset('dashboard/dist/js/toggle-data.js') }}"></script>
	
	<!-- Counter Animation JavaScript -->
	<script src="{{ asset('dashboard/vendors/waypoints/lib/jquery.waypoints.min.js') }}"></script>
	<script src="{{ asset('dashboard/vendors/jquery.counterup/jquery.counterup.min.js') }}"></script>
	
	<!-- Morris Charts JavaScript -->
    <script src="{{ asset('dashboard/vendors/raphael/raphael.min.js') }}"></script>
    <script src="{{ asset('dashboard/vendors/morris.js/morris.min.js') }}"></script>
	
	<!-- EChartJS JavaScript -->
    <script src="{{ asset('dashboard/vendors/echarts/dist/echarts-en.min.js') }}"></script>

	<!-- Owl JavaScript -->
    <script src="{{ asset('dashboard/vendors/owl.carousel/dist/owl.carousel.min.js') }}"></script>
	
	<!-- Toastr JS -->
    <script src="{{ asset('dashboard/vendors/jquery-toast-plugin/dist/jquery.toast.min.js') }}"></script>
    
    <!-- Init JavaScript -->
    <script src="{{ asset('dashboard/dist/js/init.js') }}"></script>
	<script src="{{ asset('dashboard/dist/js/dashboard4-data.js') }}"></script>
