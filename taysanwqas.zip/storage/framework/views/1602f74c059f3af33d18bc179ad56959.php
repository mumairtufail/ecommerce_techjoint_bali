<!-- All JavaScript files
    ================================================== -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Plugins for this template -->
    <script src="<?php echo e(asset('assets/js/modernizr.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.dlmenu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-plugin-collection.js')); ?>"></script>
    <!-- Custom script for this template -->
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script><?php /**PATH D:\taysan\resources\views/web/partials/scripts.blade.php ENDPATH**/ ?>