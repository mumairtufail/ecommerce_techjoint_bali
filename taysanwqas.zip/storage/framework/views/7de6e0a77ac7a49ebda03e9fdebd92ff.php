<div class="ts-toast">
    <!-- Toast message will be dynamically added here -->
</div><?php /**PATH D:\taysan\resources\views/web/shop/partials/toast.blade.php ENDPATH**/ ?>