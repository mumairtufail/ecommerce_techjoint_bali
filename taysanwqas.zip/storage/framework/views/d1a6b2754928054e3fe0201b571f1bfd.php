<div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <p>Pampered by<a href="https://lumenialab.com/" class="text-dark" target="_blank">Hencework</a> © 2025</p>
                        </div>
                        
                    </div>
                </footer>
            </div><?php /**PATH D:\taysan\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>