<button class="ts-floating-cart-btn" id="floatingCartBtn">
    <i class="fas fa-shopping-cart"></i>
    <span class="ts-cart-count">0</span>
</button><?php /**PATH D:\taysan\resources\views/web/shop/partials/floating-cart.blade.php ENDPATH**/ ?>